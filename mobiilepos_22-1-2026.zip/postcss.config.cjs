module.exports = {
  plugins: {
    // Enable Tailwind CSS so components can use responsive utilities again.
    tailwindcss: {},
    autoprefixer: {},
  }
};