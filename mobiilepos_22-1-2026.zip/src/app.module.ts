// This file intentionally re-exports the real AppModule located in ./app/app.module
export { AppModule } from './app/app.module';
